
## Summary (Summarize the bug encountered concisely)
There is a bug in the application that needs to be addressed.


## Steps to reproduce     
Provide a detailed description of the steps that led to the bug.
   

## What is the current bug behavior?
 Explain the incorrect behavior or issue that is occurring due to the bug.
     

## What is the expected correct behavior?
Describe the expected behavior or outcome when the bug is fixed.

     
## Relevant logs and/or screenshots
Include any relevant logs or screenshots that can help in understanding and resolving the bug.
      

## Possible fixes
Suggest possible solutions or fixes for the bug.


## Whom do you report/ Assign To/ Tags
Specify the person or team to whom the bug should be reported or assigned. Add relevant tags if applicable.


## Priority
 Indicate the priority level of the bug (e.g., high, medium, low) based on its impact and severity.
      
